export default {
    onSessionUpdate: () => undefined
}