import React, { Component } from 'react';
import './Footer.css';

export default class Footer extends Component {
    render() {
        return (
            <footer className="footer">
               (c) 2006 - Book Library (React App)
            </footer>
        );
    }
}
