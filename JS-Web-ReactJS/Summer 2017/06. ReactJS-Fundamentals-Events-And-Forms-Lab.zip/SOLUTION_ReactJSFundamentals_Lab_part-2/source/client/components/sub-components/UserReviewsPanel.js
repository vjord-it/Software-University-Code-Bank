import React from 'react';

export default class UserReviewsPanel extends React.Component {
    constructor(props) {
        super(props);
    }

    render() {
        return (
            <div className='container'>
                <div className="list-group">
                    Hello from UserReviewsPanel
                </div>
            </div>
        );
    }
}