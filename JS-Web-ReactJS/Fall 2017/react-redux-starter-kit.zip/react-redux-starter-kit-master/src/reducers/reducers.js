import { registerReducer, loginReducer } from './authReducer';

export default {
    register: registerReducer,
    login: loginReducer,
};