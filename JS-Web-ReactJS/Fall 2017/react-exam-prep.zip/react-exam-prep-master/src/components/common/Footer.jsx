import React, { Component } from 'react';


export default class Footer extends Component {
    render() {
        return (
            <footer>
                <div className="container modal-footer">
                    <p>Furniture System &copy; SoftUni 2017</p>
                </div>
            </footer>
        );
    }
}