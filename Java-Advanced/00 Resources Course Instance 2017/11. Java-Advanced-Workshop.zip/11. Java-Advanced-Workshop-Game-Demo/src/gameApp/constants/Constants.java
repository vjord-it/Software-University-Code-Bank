package gameApp.constants;

public class Constants {
    public final static String TITLE = "SAMPLE GAME";
}
