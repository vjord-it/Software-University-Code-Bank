package game;

public class OutOfEnergyExcpetion extends Exception {

    public OutOfEnergyExcpetion(String message) {
        super(message);
    }
}
