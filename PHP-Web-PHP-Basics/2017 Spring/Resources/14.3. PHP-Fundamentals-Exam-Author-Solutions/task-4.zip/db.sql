-- --------------------------------------------------------
-- Хост:                         127.0.0.1
-- Версия на сървъра:            10.1.19-MariaDB - mariadb.org binary distribution
-- ОС на сървъра:                Win32
-- HeidiSQL Версия:              9.4.0.5125
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for skivacation
CREATE DATABASE IF NOT EXISTS `skivacation` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `skivacation`;

-- Дъмп структура за таблица skivacation.reservations
CREATE TABLE IF NOT EXISTS `reservations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `type_of_accomodation` int(11) NOT NULL,
  `number_of_children` int(11) NOT NULL,
  `number_of_adults` int(11) NOT NULL,
  `rooms` int(11) NOT NULL,
  `checkin` date NOT NULL,
  `checkout` date NOT NULL,
  `lift_pass` int(1) NOT NULL,
  `ski_instructor` int(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK__typeofaccomodation` (`type_of_accomodation`),
  CONSTRAINT `FK__typeofaccomodation` FOREIGN KEY (`type_of_accomodation`) REFERENCES `typeofaccomodation` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- Дъмп данни за таблица skivacation.reservations: ~0 rows (approximately)
/*!40000 ALTER TABLE `reservations` DISABLE KEYS */;
INSERT INTO `reservations` (`first_name`, `last_name`, `phone`, `email`, `type_of_accomodation`, `number_of_children`, `number_of_adults`, `rooms`, `checkin`, `checkout`, `lift_pass`, `ski_instructor`) VALUES
	('asd', 'asd', '255555', 'samsung@gmail.com', 2, 5, 2, 2, '2017-02-04', '2017-02-11', 1, 0);
/*!40000 ALTER TABLE `reservations` ENABLE KEYS */;

-- Дъмп структура за таблица skivacation.typeofaccomodation
CREATE TABLE IF NOT EXISTS `typeofaccomodation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `type` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- Дъмп данни за таблица skivacation.typeofaccomodation: ~3 rows (approximately)
/*!40000 ALTER TABLE `typeofaccomodation` DISABLE KEYS */;
INSERT INTO `typeofaccomodation` (`type`) VALUES
	('Btesttesttypeofaccomodationungalow'),
	('Hostel'),
	('Hotel');
/*!40000 ALTER TABLE `typeofaccomodation` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
