<?php /** @var \Models\ReserveViewData $data */ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<form method="POST">
    First Name<input type="text" name="firstName"
                     value="<?= isset($data->getFormData()['firstName']) ? $data->getFormData()['firstName'] : "" ?>"><br>
    Last Name<input type="text" name="lastName"
                    value="<?= isset($data->getFormData()['lastName']) ? $data->getFormData()['lastName'] : "" ?>"><br>
    Phone<input type="text" name="phone"
                value="<?= isset($data->getFormData()['phone']) ? $data->getFormData()['phone'] : "" ?>"><br>
    Email <input type="text" name="email"
                 value="<?= isset($data->getFormData()['email']) ? $data->getFormData()['email'] : "" ?>"><br>
    Confirm Email<input type="text" name="confirmEmail"><br>
    Type of Accommodation<select name="typeOfAccomodation"><?php foreach ($data->getTypesOfAccomodation() as $type): ?>
            <option <?= isset($data->getFormData()['typeOfAccomodation'])
            && $data->getFormData()['typeOfAccomodation'] == $type->getId()
                ? 'selected'
                : ''; ?> value="<?= $type->getId(); ?>">
                <?= $type->getType(); ?>
            </option>
        <?php endforeach; ?>

    </select><br>
    Number of children <input type="number" name="children"
                              value="<?= isset($data->getFormData()['children']) ? $data->getFormData()['children'] : "" ?>"><br>
    Number of adults <input type="number" name="adults"
                            value="<?= isset($data->getFormData()['adults']) ? $data->getFormData()['adults'] : "" ?>"><br>
    Rooms <input type="number" name="rooms"
                 value="<?= isset($data->getFormData()['rooms']) ? $data->getFormData()['rooms'] : "" ?>"><br>
    Check In Date <input type="date" name="checkIn"
                         value="<?= isset($data->getFormData()['checkIn']) ? $data->getFormData()['checkIn'] : "" ?>"><br>
    Check Out Date <input type="date" name="checkOut"
                          value="<?= isset($data->getFormData()['checkOut']) ? $data->getFormData()['checkOut'] : "" ?>"><br>
    Lift Pass <input type="checkbox" name="liftPass" <?= isset($data->getFormData()['liftPass']) ? "checked" : "" ?>>
    Ski Instructor <input type="checkbox"
                          name="skiInstructor" <?= isset($data->getFormData()['skiInstructor']) ? "checked" : "" ?>><br>
    <input type="submit" name="submit"><br>
</form>
<form action="reservations.php">
    <input type="submit" value="Reservations"/>
</form>
<h2><?= $data->getError() ?></h2>
</body>
</html>