<?php /** @var \Models\ReserveViewData $data
 * @var \Models\EditReservationViewData $reservation
 */ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<form method="POST">
    First Name<input type="text" name="firstName" value="<?= $reservation->getFirstName() ?>"><br>
    Last Name<input type="text" name="lastName" value="<?= $reservation->getLastName() ?>"><br>
    Phone<input type="text" name="phone" value="<?= $reservation->getPhone() ?>"><br>
    Email <input type="text" name="email" value="<?= $reservation->getEmail() ?>"><br>
    Type of Accommodation<select name="typeOfAccomodation"><?php foreach ($data->getTypesOfAccomodation() as $type): ?>
            <option <?= $reservation->getTypeOfAccomodation() == $type->getId()
                ? 'selected'
                : ''; ?> value="<?= $type->getId(); ?>">
                <?= $type->getType(); ?>
            </option>
        <?php endforeach; ?>

    </select><br>
    Number of children <input type="number" name="children" value="<?= $reservation->getNumberOfChildren() ?>"><br>
    Number of adults <input type="number" name="adults" value="<?= $reservation->getNumberOfAdults() ?>"><br>
    Rooms <input type="number" name="rooms" value="<?= $reservation->getRooms() ?>"><br>
    Check In Date <input type="date" name="checkIn" value="<?= $reservation->getCheckIn() ?>"><br>
    Check Out Date <input type="date" name="checkOut" value="<?= $reservation->getCheckout() ?>"><br>
    Lift Pass <input type="checkbox" name="liftPass" <?= ($reservation->getLiftPass() == 1) ? "checked" : "" ?>>
    Ski Instructor <input type="checkbox"
                          name="skiInstructor" <?= ($reservation->getSkiInstructor() == 1) ? "checked" : "" ?>><br>
    <input type="submit" name="edit"><br>
</form>
<h2><?= $data->getError() ?></h2>
</body>
</html>