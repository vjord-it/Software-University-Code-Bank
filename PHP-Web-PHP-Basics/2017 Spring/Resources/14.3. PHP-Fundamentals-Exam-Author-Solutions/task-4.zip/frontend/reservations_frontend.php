<?php /**@var \Models\ReservationsViewData[] $data */ ?>
<table border="2px solid black">
    <thead>
    <tr>
        <th>id</th>
        <th>Name</th>
        <th>phone</th>
        <th>email</th>
        <th>Reservation Info</th>
        <th>Update</th>
        <th>Delete></th>
    </tr>
    </thead>
    <tbody>
    <?php foreach ($data as $reservation): ?>
        <tr>
            <td><?= $reservation->getId() ?></td>
            <td><?= $reservation->getFirstName() . " " . $reservation->getLastName() ?></td>
            <td><?= $reservation->getPhone() ?></td>
            <td><?= $reservation->getEmail() ?></td>
            <td><?= $reservation->getTypeOfAccomodation() . ", Rooms - " . $reservation->getRooms() . ", Children - " . $reservation->getNumberOfChildren() . ", Adults - " . $reservation->getNumberOfAdults() . ", Check In - " . $reservation->getCheckin() . ", Check Out - " . $reservation->getCheckout() . ", ";
                if ($reservation->getLiftPass() == 1) {
                    echo " Lift Pass ";
                }
                if ($reservation->getSkiInstructor() == 1) {
                    echo " Ski Instructor ";
                } ?></td>
            <td><a href="editReservation.php?id=<?= $reservation->getId() ?>">Update</a></td>
            <td><a href="deleteReservation.php?id=<?= $reservation->getId() ?>">Delete</a></td>
        </tr>
    <?php endforeach; ?>

    </tbody>
</table>