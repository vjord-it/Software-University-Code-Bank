<?php
require_once "app.php";
$data = $reserveService->getReserveViewData();
if (isset($_GET['id'])) {
    $reservation = $reservationService->getById($_GET['id']);
}
if (isset($_POST['edit'])) {
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $typeOfAcc = $_POST['typeOfAccomodation'];
    $numberOfChildren = $_POST['children'];
    $numberofAdults = $_POST['adults'];
    $rooms = $_POST['rooms'];
    $checkIn = $_POST['checkIn'];
    $checkOut = $_POST['checkOut'];
    $liftPass = 0;
    $skiInstructor = 0;
    if (isset($_POST['liftPass'])) {
        $liftPass = 1;
    }
    if (isset($_POST['skiInstructor'])) {
        $skiInstructor = 1;
    }
    try {
        $reservationService->editById($_GET['id'], $firstName, $lastName, $phone, $email, $typeOfAcc, $numberOfChildren, $numberofAdults,
            $rooms, $checkIn, $checkOut, $liftPass, $skiInstructor);
        header("Location: reserve.php");
        exit;
    } catch (\Exception $e) {
        $data->setError($e->getMessage());

    }


}
$loader->loadTemplate("editReservation_frontend", $data, $reservation);