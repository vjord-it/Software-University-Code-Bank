<?php


namespace Services;


use Adapter\DatabaseInterface;
use Models\EditReservationViewData;
use Models\ReservationsViewData;

class ReservationService implements ReservationServiceInterface
{
    const  EMAIL_PATTERN = "/(([^<>()\[\]\\.,;:\s@\"]+(\.[^<>()\[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/";
    private $db;

    public function __construct(DatabaseInterface $db)
    {
        $this->db = $db;
    }

    public function addReservation($firstName, $lastName, $phone, $email, $confirmEmail, $typeOfAcc, $numberOfChildren, $numberOfAdults,
                                   $rooms, $checkIn, $checkOut, $liftPass, $skiInstructor)
    {
        $checkIn = new \DateTime($checkIn);
        $checkOut = new \DateTime($checkOut);
        if ($email != $confirmEmail) {
            throw new \Exception("Email missmatch");
        }
        if (!preg_match(self::EMAIL_PATTERN, $email)) {
            throw new \Exception("Email not valid");
        }
        if ($checkIn > $checkOut) {
            throw new \Exception("Check in date should be before check out date ");
        }

        $query = "INSERT
 INTO reservations
  (first_name,
  last_name
  ,phone
  ,email
  ,type_of_accomodation
  ,number_of_children
  ,number_of_adults
  ,rooms
  ,checkin
  ,checkout
  ,lift_pass
  ,ski_instructor)
VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";

        $stmt = $this->db->prepare($query);
        $stmt->execute([
            $firstName,
            $lastName,
            $phone,
            $email,
            $typeOfAcc,
            $numberOfChildren,
            $numberOfAdults,
            $rooms,
            $checkIn->format("Y-m-d"),
            $checkOut->format("Y-m-d"),
            $liftPass,
            $skiInstructor
        ]);


    }

    public function getById($id)
    {
        $query = "SELECT * FROM reservations WHERE id = ?";
        $stmt = $this->db->prepare($query);
        $stmt->execute([$id]);
        $obj = $stmt->fetchObject(EditReservationViewData::class);
        return $obj;

    }

    public function deleteById($id)
    {
        $query = "DELETE FROM reservations WHERE id=?";
        $this->db->prepare($query)->execute([$id]);

    }

    public function editById($id, $firstName, $lastName, $phone, $email, $typeOfAcc, $numberOfChildren, $numberOfAdults,
                             $rooms, $checkIn, $checkOut, $liftPass, $skiInstructor)
    {
        $checkIn = new \DateTime($checkIn);
        $checkOut = new \DateTime($checkOut);

        if ($checkIn > $checkOut) {
            throw new \Exception("Check in date should be before check out date ");
        }
        if (!preg_match(self::EMAIL_PATTERN, $email)) {
            throw new \Exception("Email not valid");
        }
        $query = "UPDATE reservations SET first_name = ?, 
                    last_name = ?,
                    phone =?,
                    email = ?, 
                    type_of_accomodation = ?,
                    number_of_children=?,
                    number_of_adults=?,
                    rooms=?,
                    checkin=?,
                    checkout=?,
                    lift_pass=?,
                    ski_instructor=?
                     WHERE id = ?";
        $stmt = $this->db->prepare($query);
        $stmt->execute([$firstName, $lastName, $phone, $email, $typeOfAcc, $numberOfChildren, $numberOfAdults,
            $rooms, $checkIn->format("Y-m-d"), $checkOut->format("Y-m-d"), $liftPass, $skiInstructor, $id]);
    }

    public function getAll()
    {
        $query = "SELECT R.id, R.first_name,
                        R.last_name,
                        R.phone, 
                        R.email,  
                        T.`type` as type_of_accomodation, 
                        R.number_of_children, 
                        R.number_of_adults, 
                        R.rooms, 
                        R.checkin, 
                        R.checkout ,
                        R.lift_pass,
                        R.ski_instructor 
                        FROM reservations R 
                        JOIN typeofaccomodation T
                        ON R.type_of_accomodation=T.id
                        ORDER BY
                        R.checkin,R.checkout";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        while ($obj = $stmt->fetchObject(ReservationsViewData::class)) {
            yield $obj;
        }
    }
}