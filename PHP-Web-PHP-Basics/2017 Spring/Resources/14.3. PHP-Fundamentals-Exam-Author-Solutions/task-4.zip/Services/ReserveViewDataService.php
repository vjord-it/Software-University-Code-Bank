<?php


namespace Services;


use Adapter\DatabaseInterface;

class ReserveViewDataService implements ReserveViewDataServiceInterface
{
    private $db;

    public function __construct(DatabaseInterface $db)
    {
        $this->db = $db;
    }


    public function getReserveViewData()
    {
        $data = new \Models\ReserveViewData();
        $query = "SELECT id, type FROM typeofaccomodation";
        $stmt = $this->db->prepare($query);
        $stmt->execute();


        $data->setTypesOfAccomodation(function () use ($stmt) {
            while ($obj = $stmt->fetchObject(\Models\TypeOfAccomodation::class)) {
                yield $obj;
            }
        });
        return $data;


    }
}