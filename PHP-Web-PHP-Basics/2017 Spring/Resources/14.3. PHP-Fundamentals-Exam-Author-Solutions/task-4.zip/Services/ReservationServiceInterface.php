<?php
/**
 * Created by PhpStorm.
 * User: Notebook
 * Date: 19.3.2017 г.
 * Time: 14:11
 */

namespace Services;


interface ReservationServiceInterface
{

    public function addReservation($firstName, $lastName, $phone, $email, $confirmEmail, $typeOfAcc, $numberOfChildren, $numberOfAdults,
                                   $rooms, $checkIn, $checkOut, $liftPass, $skiInstructor);

    public function getAll();
}