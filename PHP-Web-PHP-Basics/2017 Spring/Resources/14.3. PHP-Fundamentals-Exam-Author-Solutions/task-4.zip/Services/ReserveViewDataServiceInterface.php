<?php
/**
 * Created by PhpStorm.
 * User: Notebook
 * Date: 19.3.2017 г.
 * Time: 13:04
 */

namespace Services;


interface ReserveViewDataServiceInterface
{
    public function getReserveViewData();

}