<?php
namespace Core;
class Loader
{
    const FRONTEND_FOLDER="frontend";
    public function loadTemplate($templateName, $data = null, $reservation=null)
    {
        include self::FRONTEND_FOLDER
            . '/'
            . $templateName
            . '.php';
    }
}