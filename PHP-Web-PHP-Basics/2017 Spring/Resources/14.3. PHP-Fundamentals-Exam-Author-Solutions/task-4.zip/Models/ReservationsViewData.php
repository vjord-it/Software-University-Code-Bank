<?php

namespace Models;


class ReservationsViewData
{
    private $id;
    private $first_name;
    private $last_name;
    private $phone;
    private $email;
    private $type_of_accomodation;
    private $number_of_children;
    private $number_of_adults;
    private $rooms;
    private $checkin;
    private $checkout;
    private $lift_pass;
    private $ski_instructor;

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @return mixed
     */
    public function getFirstName()
    {
        return $this->first_name;
    }

    /**
     * @return mixed
     */
    public function getLastName()
    {
        return $this->last_name;
    }

    /**
     * @return mixed
     */
    public function getPhone()
    {
        return $this->phone;
    }

    /**
     * @return mixed
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * @return mixed
     */
    public function getTypeOfAccomodation()
    {
        return $this->type_of_accomodation;
    }

    /**
     * @return mixed
     */
    public function getNumberOfChildren()
    {
        return $this->number_of_children;
    }

    /**
     * @return mixed
     */
    public function getNumberOfAdults()
    {
        return $this->number_of_adults;
    }

    /**
     * @return mixed
     */
    public function getRooms()
    {
        return $this->rooms;
    }

    /**
     * @return mixed
     */
    public function getCheckin()
    {
        return $this->checkin;
    }

    /**
     * @return mixed
     */
    public function getCheckout()
    {
        return $this->checkout;
    }

    /**
     * @return mixed
     */
    public function getLiftPass()
    {
        return $this->lift_pass;
    }

    /**
     * @return mixed
     */
    public function getSkiInstructor()
    {
        return $this->ski_instructor;
    }


}