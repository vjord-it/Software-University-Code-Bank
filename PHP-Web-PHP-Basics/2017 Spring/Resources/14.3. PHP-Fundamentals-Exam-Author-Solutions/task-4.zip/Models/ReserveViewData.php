<?php

namespace Models;

class ReserveViewData
{
    /** @var TypeOfAccomodation[] $types_of_accomodation */
    private $types_of_accomodation;
    private $formData = [];
    private $error;

    /**
     * @return mixed
     */
    public function getFormData()
    {
        return $this->formData;
    }

    /**
     * @param mixed $formData
     */
    public function setFormData($formData)
    {
        $this->formData = $formData;
    }


    /**
     * @return mixed
     */
    public function getError()
    {
        return $this->error;
    }

    /**
     * @param mixed $error
     */
    public function setError($error)
    {
        $this->error = $error;
    }


    public function getTypesOfAccomodation()
    {
        return $this->types_of_accomodation;
    }


    public function setTypesOfAccomodation(callable  $types_of_accomodation)
    {
        $this->types_of_accomodation = $types_of_accomodation();
    }


}