<?php
require_once "app.php";


$loader->loadTemplate("reservations_frontend", $reservationService->getAll());