<?php
require_once "app.php";
if (isset($_GET['id'])) {
    $reservationService->deleteById($_GET['id']);
    header("Location: reservations.php");
    exit;
}
$loader->loadTemplate("delete_frontend");