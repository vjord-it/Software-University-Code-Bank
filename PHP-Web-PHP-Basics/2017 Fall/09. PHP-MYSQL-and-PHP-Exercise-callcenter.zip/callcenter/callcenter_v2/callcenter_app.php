<?php
/* Main entry point:
 php callcenter_app.php
*/
include "Database.php";
include "CallCenter.php";
$geography = new Database();
$db = $geography->connect(); // Connection to DB (PDO)
$app = new CallCenter($db);
$app->main();
$geography->disconnect();