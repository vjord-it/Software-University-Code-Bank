<?php
/* For now the input and output is done here. But a real application would use some kind of a template system for the output and also separate the handling of database queries from data control. This would require much more coding but would allow much better maintenance. */
class CallCenter
{
    private $db = false;

    public function __construct($db){
        $this->db = $db;
    }

    public function main(){
        do{
            $input_str = trim(fgets(STDIN));
            // Todo
            /* Input logic for the other problems will change
            the content of this method as you need to work on the
            input. To enter country info is the default mode.
            */
            $res = $this->getCountryInfo($input_str);
            if($res){
                echo "Country:".$res['country_name'].PHP_EOL;
                echo "Capital:".$res['capital'].PHP_EOL;
            }
            else{
                echo "Country not found.\n\r";
            }
        }
        while($input_str != "Bye");
    }

    private function getCountryInfo( $str ){
        if(empty($str) or mb_strlen($str, 'utf8') < 2){
            return false;
        }
        switch (mb_strlen($str, 'utf8')) {
            case 2:
                $where_str = " `country_code` = ?";
                break;
            case 3:
                $where_str = " `iso_code` = ?";
                break;
            default:
                $where_str = " `country_name` = ?";

                break;
        }
        $stmt = $this->db->prepare("
          SELECT `country_name`, `capital`
            FROM `countries`
            WHERE  $where_str ");
        $stmt->execute( array($str) );
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        /* If no rows the $row is false!
        Now we know if there is a result */
        return($row);
    }

    private function getCurrencyContinent(){
        //Todo
    }

    private function isMountinCountry(){
        //Todo
    }

    private function isSpecialEquipment(){
        //Todo
    }

    private function addCustomer(){
        //Todo
    }

    private function delCustomer(){
        //Todo
    }
}