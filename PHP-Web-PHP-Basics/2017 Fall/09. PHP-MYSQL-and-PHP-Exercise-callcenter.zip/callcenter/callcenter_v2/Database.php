<?php
/* This class encapsulates the database. For now it returns an instance of PDO. But it could contain its own methods to handle queries to the DB and use multiple DB drivers. */
class Database
{
    // Attributes
    private $db_host     = "localhost";
    private $db_name     = "geography";
    private $db_user     = "root";
    private $db_password = 'pass4mysql';
    private $pdo         = false;

    // Methods
    public function __construct(){
       $this->pdo = new PDO("mysql:dbname=".$this->db_name.";host=".$this->db_host, $this->db_user, $this->db_password);
       if($this->pdo) {
           $this->setErrorException();// default - throw exceptions
           return $this->pdo;
       }
       else{
           throw new Exception("Could not connect to DB.");
       }
    }

    public function connect(){
        return $this->pdo;
    }

    public function disconnect(){
        $this->pdo = null;
    }

    public function setErrorException(){
        if($this->pdo)
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }

};