<?php
/*
Here the database functionality extends the PDO class and everything is capsulated in the Database class. We create an instance of the Database in the method connectDB in the CallCenter class. But what if we want to extend the functionality with another class which also uses the database? You can extend PDO but this is not always a good idea because you may want to stop using it or be able to use multi DB drivers? 
*/s
class Database extends PDO
{
    // Attributes
    private $db_host     = "localhost";
    private $db_name     = "geography";
    private $db_user     = "root";
    private $db_password = 'pass4mysql';
    private $db          = false;

    // Methods
    public function __construct(){
        parent::__construct( "mysql:dbname=".$this->db_name.";host=".$this->db_host, $this->db_user, $this->db_password);
    }

    public function setErrorException(){
		// If there is an SQL error throw an exception and show it
        $this->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }

    public function connect(){
        $this->setErrorException();
        return($this);
    }
};