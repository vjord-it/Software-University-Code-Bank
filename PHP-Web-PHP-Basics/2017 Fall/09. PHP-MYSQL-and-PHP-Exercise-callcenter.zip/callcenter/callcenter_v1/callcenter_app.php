<?php
/* Main entry point:
   php callcenter_app.php
*/
include "Database.php";
include "CallCenter.php";
$app = new CallCenter();
$app->main();