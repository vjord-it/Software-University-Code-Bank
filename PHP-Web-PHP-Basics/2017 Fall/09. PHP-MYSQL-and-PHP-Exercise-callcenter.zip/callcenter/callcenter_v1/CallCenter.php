<?php
class CallCenter
{
    private $dbi = false;

    public function connectDB(){
        $db = new Database(); //Instance of the database. But we can use it only in the class now!
        $this->dbi = $db->connect();
    }

    public function __construct(){
        $this->connectDB();
    }

    public function main(){
        //Todo - Input/Output and input from STDIN
        do{
            $input_str = trim(fgets(STDIN));
            // Todo
            $res = $this->getCountryInfo($input_str);
            if($res != false ){
                $flag = false; // flag for results
                foreach($res as $i => $iv){
                    echo "Country:".$iv['country_name']."\n\r";
                    echo "Capital:".$iv['capital']."\n\r";
                    $flag = true; // at least one result
                    break;
                }
                if($flag == false){
                    echo "Country not found.\n\r";
                }
            }
            else{
                echo "Could not read from DB.\n\r";
            }
        }
        while($input_str != "Bye");
    }

    private function getCountryInfo( $str ){
		/* We can write a query like this because of the different format of data. If country_name, country_code and is_code could have the same information in two different rows our logic would brake. This is a lazy approach. */
        $result = $this->dbi->query("
            SELECT `country_name`, `capital`
                FROM `countries`
                WHERE  `country_name` = \"$str\" 
                    OR `country_code` = \"$str\"
                    OR `iso_code`     = \"$str\" 
                LIMIT 0,1");
        /* We don't know the number of results here. Even if
        there are no results query returns an object */
        if(is_object($result))
            return($result);
        else
            return(false);
    }

    private function getCurrencyContinent(){
        //Todo
    }

    private function isMountinCountry(){
        //Todo
    }

    private function isSpecialEquipment(){
        //Todo
    }

    private function addCustomer(){
        //Todo
    }

    private function delCustomer(){
        //Todo
    }
}