<form>
	<input type="text" name="input">
	<input type="submit" value=" Go "/>
</form>
	