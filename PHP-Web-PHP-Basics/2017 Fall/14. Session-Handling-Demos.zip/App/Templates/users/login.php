<h1> USER LOGIN </h1>
<form method="POST">
    <div>
        <label>
            Username:
            <input type="text" name="username"/>
        </label>
    </div>
    <div>
        <label>
            Password:
            <input type="text" name="password"/>
        </label>
    </div>
    <div>
        <input type="submit" name="login" value="Login!"/>
    </div>
</form>