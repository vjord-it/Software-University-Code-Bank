<h1> USER REGISTER </h1>
<form method="POST">
    <div>
        <label>
            Username:
            <input type="text" name="username"/>
        </label>
    </div>
    <div>
        <label>
            Password:
            <input type="text" name="password"/>
        </label>
    </div>
    <div>
        <label>
            Confirm Password:
            <input type="text" name="confirm_password"/>
        </label>
    </div>
    <div>
        <label>
            First Name:
            <input type="text" name="firstName"/>
        </label>
    </div>
    <div>
        <label>
            Last Name:
            <input type="text" name="lastName"/>
        </label>
    </div>
    <div>
        <label>
            Birthday:
            <input type="text" name="bornOn"/>
        </label>
    </div>
    <div>
        <input type="submit" name="register" value="Register!"/>
    </div>
</form>