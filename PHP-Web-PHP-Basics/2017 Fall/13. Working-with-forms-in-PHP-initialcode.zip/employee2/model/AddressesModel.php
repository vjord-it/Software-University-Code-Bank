<?php

class AddressesModel extends Model
{

    // Todo

}