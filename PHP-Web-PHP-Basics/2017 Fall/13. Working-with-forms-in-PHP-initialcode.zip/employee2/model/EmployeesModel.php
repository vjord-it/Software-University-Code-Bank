<?php

class EmployeesModel extends Model
{
    // Todo

}