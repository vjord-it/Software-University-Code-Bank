<html>
	<head>
		<title>Change the Title</title>
		<link href="view/style.css" rel="stylesheet" type="text/css"/>
	</head>
	<body>