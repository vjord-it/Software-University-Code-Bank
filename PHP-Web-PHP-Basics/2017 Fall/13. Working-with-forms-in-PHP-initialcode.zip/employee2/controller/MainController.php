<?php

class MainController extends Controller
{

    public function main()
    {
        // Todo
    }

}