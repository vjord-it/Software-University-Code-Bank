#include <stdio.h>
#include <stdlib.h>

#define SIZE 100

int main() 
{
    int *nums = calloc(SIZE, sizeof(int));
    if (!nums)
    {
        printf("Not enough memory.");
        return 1;
    }
    
    int i;
    for (i = 0; i < SIZE; i++)
    {
        printf("%d ", nums[i]);
    }
    
    free(nums);
    
    return (EXIT_SUCCESS);
}

