#include <stdio.h>
#include <stdlib.h>

char *get_next_input()
{
    char *buffer = malloc(10);
    if (!buffer)
    {
        return NULL;
    }
    
    fgets(buffer, 10, stdin);
    
    return buffer;
}

int main() 
{
    while (1)
    {
        char *input = get_next_input();
        if (input == NULL)
        {
            printf("Out of memory!");
        }
        
        // Forgetting to free causes memory leaks
        // free(input);
    }
    
    return (EXIT_SUCCESS);
}
