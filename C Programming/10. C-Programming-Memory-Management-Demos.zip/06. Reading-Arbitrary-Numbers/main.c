#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define INITIAL_SIZE 4

int main() 
{
    char *line = NULL;
    size_t size = 0;
    size_t length = getline(&line, &size, stdin);
    
    char *token = strtok(line, " ");
    int *array = malloc(INITIAL_SIZE * sizeof(int));
    if (!array)
    {
        printf("Not enough memory for initial array\n");
        return 1;
    }
    
    size_t i = 0, arrayLength = INITIAL_SIZE;
    while (token)
    {
        int num = atoi(token);
        if (i == arrayLength)
        {
            int *newArray = 
            realloc(array, arrayLength * 2 * sizeof(int));
            if (!newArray)
            {
                printf("Not enough when resizing array\n");
                return 1;
            }
            
            array = newArray;
            arrayLength *= 2;
        }
        
        array[i] = num;
        i++;
        
        token = strtok(NULL, " ");
    }
    
    size_t j;
    for (j = 0; j < i; j++)
    {
        printf("%d ", array[j]);
    }
    
    free(line);
    free(array);
    
    return (EXIT_SUCCESS);
}

