#include <stdio.h>
#include <stdlib.h>

#define MIN 5
#define MAX 7

int *get_range(int, int);

int main() 
{
    int *nums = get_range(MIN, MAX);
    if (!nums)
    {
        return 1;
    }
    
    int i;
    
    for (i = 0; i <= MAX - MIN; i++)
        printf("%d ", nums[i]);
    
//    free(nums);
    
    return 0;
}

int *get_range(int min, int max) 
{
    int length = max - min;
    int nums[length + 1];  // Fix!
//    int *nums = malloc((length + 1) * sizeof(int));
    if (!nums)
    {
        return NULL;
    }
    
    int i;
    for (i = 0; i <= length; i++)
        nums[i] = min++;
    
    return nums;
}