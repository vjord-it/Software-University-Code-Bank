#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char** argv) {
    
    char *str1 = "ABC";
    char *str2 = "ABC";
    int result = memcmp(str1, str2, 3);
    printf("%d", result);
    
    return (EXIT_SUCCESS);
}

