#include <stdio.h>
#include <stdlib.h>

int main(int argc, char** argv) 
{
    int n = 1000;
    int *nums = malloc(1000 * sizeof(int));
    if (!nums)
    {
        return 1;
    }
    
    int i;
    for (i = 0; i < n - 200; i++)
    {
        nums[i] = i;
    }
    
    int *newNums = realloc(nums, (n - 200) * sizeof(int));
    if (!newNums)
    {
        return 1;
    }
    
    nums = newNums;
    for (i = 0; i < n - 200; i++)
    {
        printf("%d ", nums[i]);
    }
    
    free(nums);
    
    return (EXIT_SUCCESS);
}

