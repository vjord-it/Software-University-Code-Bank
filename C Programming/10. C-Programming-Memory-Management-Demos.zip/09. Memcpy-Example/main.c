#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() 
{
    int source[] = { 3, 5, 1, 10 };
    int destination[2];
    size_t size = sizeof(destination) / sizeof(int);
    memcpy(destination, source, size * sizeof(int));
    int i;
    for (i = 0; i < size; i++)
    {
        printf("%d ", destination[i]);
    }
    
    return (EXIT_SUCCESS);
}

