#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() 
{
    char *text = malloc(100);
    if (!text)
    {
        printf("Not enough memory");
        return 1;
    }
    
    int i, j = 0;
    for (i = 65; i <= 90; i++, j++)
    {
        text[j] = i;
    }

    text[j] = '\0';
    printf("%s\n", text);

    free(text);
    
    return (EXIT_SUCCESS);
}
