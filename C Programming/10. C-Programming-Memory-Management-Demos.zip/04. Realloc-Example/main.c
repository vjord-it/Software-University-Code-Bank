#include <stdio.h>
#include <stdlib.h>

int main() 
{
    char *text = malloc(3);
    if (!text)
    {
        printf("Not enough memory");
        return 1;
    }
    char *next = malloc(3);
    
    text[0] = 'A';
    text[1] = 'B';
//    text[2] = 'C'; // Invalid - overwriting end of string!
//    text[3] = 'D'; // Invalid memory write!
    char *newText = realloc(text, 10);
    if (!newText)
    {
        printf("Not enough memory to resize string");
        return 1;
    }
    
    text = newText;
    text[2] = 'C';
    text[3] = 'D';
    text[4] = '\0';
    
    printf("%s\n", text);
    free(text);
    
    return (EXIT_SUCCESS);
}

