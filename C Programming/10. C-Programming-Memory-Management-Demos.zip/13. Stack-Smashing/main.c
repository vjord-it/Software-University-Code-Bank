#include <stdio.h>
#include <stdlib.h>

struct User
{
    char name[10];
    int isAdmin;
};

int main() 
{    
    struct User user;
    user.isAdmin = 0;
    // Enter more than 10 symbols to overwrite the memory of isAdmin
    // NEVER user gets()!
    gets(user.name);
    
    if (user.isAdmin)
    {
        printf("Access granted! Press any key to launch nuclear missile...");
        getchar();
        printf("Missile launched. Have a nice day! :)");
    }
    
    return (EXIT_SUCCESS);
}

