#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() 
{
    int n = 10;
    float *nums = malloc(n * sizeof(float));
    if (!nums)
    {
        printf("Not enough memory\n");
        return 1;
    }
    
    // Zero initializes all bytes
    memset(nums, 0, n * sizeof(float));
    int i;
    for (i = 0; i < n; i++)
    {
        printf("%.2f ", nums[i]);
    }
    
    free(nums);
    
    return (EXIT_SUCCESS);
}
