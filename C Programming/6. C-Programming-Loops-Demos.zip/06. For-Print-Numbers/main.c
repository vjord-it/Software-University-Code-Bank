#include <stdio.h>
#include <stdlib.h>

int main() 
{
    int num;
    for (num = 0; num < 10; num++)
    {
        printf("%d\n", num);
    }
    
    return (EXIT_SUCCESS);
}
