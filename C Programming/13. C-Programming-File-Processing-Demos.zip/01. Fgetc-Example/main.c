#include <stdio.h>

int main()
{
    FILE *file = fopen("main.c", "r");
    if (!file)
    {
        fprintf(stderr, "Error opening file");
        return 1;
    }
    
    while (!feof(file))
    {
        char ch = fgetc(file);
        printf("%c", ch);
    }
    
    fclose(file);
    
    return 0;
}