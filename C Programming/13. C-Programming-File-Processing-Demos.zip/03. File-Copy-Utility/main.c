#include <stdio.h>
#include <stdlib.h>
#include <errno.h>

#define BUFFER_SIZE 4096

void copy(const char *, const char *);
void kill(const char *);

int main(int argc, char **argv) 
{
    // ./prog src.txt dest.txt
    if (argc < 3)
        kill("Usage: ./prog <src-file> <dest-file>");
    
    copy(argv[1], argv[2]);
    
    return (EXIT_SUCCESS);
}

void kill(const char *msg)
{
    if (errno)
    {
        perror(msg);
    }
    else 
    {   
        fprintf(stderr, "%s\n", msg);
    }
    
//    Extra log into file
//    FILE *logFile = fopen("log.txt", "a");
//    if (logFile)
//    {
//        fprintf(logFile, "%s\n", msg);
//        fclose(logFile);
//    }
    
    exit(1);
}

void copy(const char *srcPath, const char *destPath)
{
    FILE *srcFile = fopen(srcPath, "r");
    if (!srcFile)
        kill(NULL);
    
    FILE *destFile = fopen(destPath, "w");
    if (!destFile)
        kill(NULL);
    
    char buffer[BUFFER_SIZE];
    while (!feof(srcFile) && !ferror(destFile) && !ferror(destFile))
    {
        size_t bytesRead = fread(buffer, 1, BUFFER_SIZE, srcFile);
        fwrite(buffer, 1, bytesRead, destFile);
    }
    
    fclose(srcFile);
    fclose(destFile);
}

