#include <stdio.h>
#include <stdlib.h>

int main() 
{
    FILE *file = fopen("main.c", "a");
    if (!file)
        return 1;
    
    fprintf(file, "// End of %s", "main()");
    
    fclose(file);
    
    return (EXIT_SUCCESS);
}
// End of main()