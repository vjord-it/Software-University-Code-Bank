#include <stdio.h>
#include <stdlib.h>

#define BUFFER_SIZE 2

int main() 
{
    FILE *file = fopen("file.txt", "r");
    if (!file) {
        fprintf(stderr, "Error opening file");
        return 1;
    }
    
    char buffer[BUFFER_SIZE];
    while (!feof(file))
    {
        size_t readBytes = fread(buffer, 1, BUFFER_SIZE, file);
        
        buffer[readBytes] = '\0';
        printf("%s\n", buffer);    
    }
    
    fclose(file);
    
    return (EXIT_SUCCESS);
}

