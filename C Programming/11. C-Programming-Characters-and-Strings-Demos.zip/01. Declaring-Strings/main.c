#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() 
{
    char text[] = "Sweet lemonade";

    strlen(text);
    printf("%s", text);

    return (EXIT_SUCCESS);
}

