int circles_intersect(double x1, double y1, double r1,
        double x2, double y2, double r2);

int is_valid_triangle(double a, double b, double c);