#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define INITIAL_BUFFER_SIZE 64

size_t read_line(char **, size_t *);

char *get_brackets_text(char *line);

char *get_contents(const char *, size_t *);

int main() 
{
    char *line = NULL;
    size_t size = 0;
    read_line(&line, &size);
    
    char *result = get_brackets_text(line);
    if (!result)
        return 1;
    
    size_t resultLen = strlen(result);
    read_line(&line, &size);
    while (strcmp(line, "end") != 0)
    {
        // Split and parse command parameters
        strtok(line, " ");
        int posOne = atoi(strtok(NULL, " "));
        int posTwo = atoi(strtok(NULL, " "));
        int cpySize = atoi(strtok(NULL, " "));
        
        // Validate parameters
        int isValidPosOne = posOne >= 0 && posOne < resultLen;
        int isValidPosTwo = posTwo >= 0 && posTwo < resultLen;
        int isValidSize = cpySize >= 0 &&
                cpySize + posOne < resultLen &&
                cpySize + posTwo < resultLen;
        
        if (isValidPosOne && isValidPosTwo && isValidSize)
        {
            char firstHalf[cpySize];
            strncpy(firstHalf, result + posOne, cpySize);
            strncpy(result + posOne, result + posTwo, cpySize);
            strncpy(result + posTwo, firstHalf, cpySize);
        }
        else
        {
            printf("Invalid command parameters\n");
        }
        
        read_line(&line, &size);
    } 
    
    free(line);
    
    printf("%s", result);
    free(result);
    
    return (EXIT_SUCCESS);
}

size_t read_line(char **line, size_t *size)
{
    char *result = *line;
    if (!result)
    {
        result = (char*) malloc(INITIAL_BUFFER_SIZE);
        if (!result)
            return 0;
    }
    
    size_t index = 0;
    size_t currentSize = INITIAL_BUFFER_SIZE;
    char ch = getchar();
    while (ch != '\n' && ch != EOF)
    {
        if (index == currentSize - 1)
        {
            char *resized = (char*) realloc(result, currentSize * 2);
            if (!resized)
                return 0;
            result = resized;
            currentSize *= 2;
        }
        result[index] = ch;
        index++;
        ch = getchar();
    }
    
    result[index] = '\0';
    *line = result;
    *size = currentSize;
	
    return index - 1;
}

char *get_brackets_text(char *line)
{
    size_t length = INITIAL_BUFFER_SIZE, index = 0;
    char *result = (char*) calloc(length, 1);
    if (!result)
        return NULL;
    
    char *token = strtok(line, "|");
    while (token)
    {
        size_t contentsLength = 0;
        char *contents = get_contents(token, &contentsLength);
        if (contents)
        {
            size_t newSize = index + contentsLength;
            if (newSize >= length)
            {
                char *resized = (char*) realloc(result, length * 2);
                if (!resized)
                    return NULL;
                
                result = resized;
                length *= 2;
            }
            
            strncat(result, contents, contentsLength);
            index += contentsLength;
        }
            
        result[index] = '\0';
        
        token = strtok(NULL, "|");
    }
    
    return result;
}

char *get_contents(const char *str, size_t *length)
{
    char *openingBracket = strchr(str, '{');
    if (!openingBracket)
        return NULL;
    
    char *closingBracket = strchr(openingBracket + 1, '}');
    if (!closingBracket)
    {
        return NULL;
    }
    
    *length = closingBracket - openingBracket - 1;
    return openingBracket + 1;
}
