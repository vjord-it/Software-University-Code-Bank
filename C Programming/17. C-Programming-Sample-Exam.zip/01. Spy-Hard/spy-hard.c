#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_NUMBER_SIZE 2
#define MAX_MESSAGE_SIZE 100

int main() 
{
	// Read 2 digits + \n + null terminator
    char number[MAX_NUMBER_SIZE + 2];
    fgets(number, MAX_NUMBER_SIZE + 2, stdin);
    int base = atoi(number);
    
    char message[MAX_MESSAGE_SIZE + 1];
    fgets(message, MAX_MESSAGE_SIZE + 1, stdin);
    size_t length = strlen(message);
    if (message[length - 1] == '\n')
        message[length - 1] = '\0';
    
    unsigned int sum = 0;
    int i;
    for (i = 0; i < length; i++)
    {
        char currentChar = message[i];
        if (isalpha(currentChar))
            sum += toupper(currentChar) - 'A' + 1;
        else 
            sum += currentChar;
    }
    
    char digits[33];
    i = 0;
    while (sum > 0)
    {
        int digit = sum % base;
        digits[i] = digit;
        sum /= base;
        i++;
    }
    
    printf("%d", base);
    printf("%lu", strlen(message));
    
    i--;
    while (i >= 0)
    {
        printf("%d", digits[i]);
        i--;
    }
    
    return (EXIT_SUCCESS);
}
