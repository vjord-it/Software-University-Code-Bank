#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>

#define BUFFER_SIZE 4096

void kill(const char *);

void kill(const char *msg)
{
    if (errno)
        perror(msg);
    else 
        fprintf(stderr, "ERROR: %s", msg);
    
    exit(1);
}

int main(int argc, char **argv) 
{
    if (argc < 3)
        kill("Usage: <src-file> <dest-file>");
    
    const char *srcFileName = argv[1];
    const char *destFileName = argv[2];
    
    FILE *srcFile = fopen(srcFileName, "r");
    if (!srcFile)
        kill(srcFileName);
    
    FILE *destFile = fopen(destFileName, "w");
    if (!destFile)
        kill(destFileName);
    
    char buffer[BUFFER_SIZE];
    while (!feof(srcFile))
    {
        int readBytes = fread(buffer, 1, BUFFER_SIZE, srcFile);
        
        if (ferror(srcFile))
            kill("Error reading from source");
        
        size_t firstPartSize = readBytes / 2;
        size_t secondPartSize = readBytes - firstPartSize;
        size_t diff = secondPartSize - firstPartSize;
        
        char temp[firstPartSize];
        memcpy(temp, buffer, firstPartSize);
        memmove(buffer, buffer + firstPartSize, secondPartSize);
        memcpy(buffer + firstPartSize + diff, temp, firstPartSize);
        
        fwrite(buffer, 1, readBytes, destFile);
    }
    
    fclose(srcFile);
    fclose(destFile);
    
    return (EXIT_SUCCESS);
}

