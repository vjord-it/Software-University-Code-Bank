#include <stdio.h>
#include <stdlib.h>

void pass_by_value(int);
void pass_by_reference(int*);


int main() 
{
    int num = 5;
    // Pass a copy of num to function
    pass_by_value(num);
    // Num remains the same
    printf("%d\n", num);
    
    // Pass a pointer to the memory of num
    pass_by_reference(&num);
    printf("%d\n", num);
    
    return (EXIT_SUCCESS);
}

void pass_by_value(int num)
{
    num++;
}

void pass_by_reference(int *num)
{
    (*num)++;
}