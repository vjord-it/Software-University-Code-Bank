#include <stdio.h>
#include <stdlib.h>

int even(int num);
int positive(int num);
int negative(int num);
int *array_filter(int*, size_t, size_t*, int (*func)(int));

int main() 
{
    int array[] = { 5, 2, -1, 7, -3, -10 };
    size_t size = sizeof(array) / sizeof(int);
    size_t resultSize;
    int *result = array_filter(array, size, &resultSize, &negative);
    if (!result)
    {
        printf("Error filtering array.\n");
        return 1;
    }
    
    int i;
    printf("These are the numbers: \n");
    for (i = 0; i < resultSize; i++)
    {
        printf("%d ", result[i]);
    }
    
    free(result);
    
    return (EXIT_SUCCESS);
}

int *array_filter(int *arr, size_t size, size_t *resultSize,
    int (*func)(int))
{
    int *result = malloc(size * sizeof(int));
    if (!result)
    {
        // Not enough memory to allocate
        return NULL;
    }
    
    int i, index = 0;
    for (i = 0; i < size; i++)
    {
        if ((*func)(arr[i]))
        {
            result[index] = arr[i];
            index++;
        }
    }
    
    *resultSize = index;
    
    return result;
}

int even(int num)
{
    return num % 2 == 0;
}

int positive(int num)
{
    return num > 0;
}

int negative(int num)
{
    return num < 0;
}