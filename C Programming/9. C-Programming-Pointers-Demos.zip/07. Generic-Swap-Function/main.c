#include <stdio.h>
#include <stdlib.h>

void swap(void*, void*, int);

int main(int argc, char** argv) 
{
    int a = 5;
    int b = 33;
    swap(&a, &b, sizeof(a));
    printf("%d %d\n", a, b);
    
    char c = 'C';
    char d = 'D';
    swap(&c, &d, sizeof(c));
    printf("%c %c\n", c, d);
    
    return (EXIT_SUCCESS);
}

void swap(void *a, void *b, int size)
{
    char *aPtr = a;
    char *bPtr = b;
    size_t i;
    for (i = 0; i < size; i++)
    {
        char oldValue = aPtr[i];
        aPtr[i] = bPtr[i];
        bPtr[i] = oldValue;
    }
}