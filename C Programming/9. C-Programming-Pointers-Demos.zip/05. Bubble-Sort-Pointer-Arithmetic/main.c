#include <stdio.h>
#include <stdlib.h>

void bubble_sort(int *array, size_t length);

int main() 
{
    int array[] = { 5, 1, 3, -2 };
    int size = sizeof(array) / sizeof(int);
    bubble_sort(array, size);
    int i;
    for (i = 0; i < size; i++)
    {
        printf("%d\n", array[i]);
    }
    
    return (EXIT_SUCCESS);
}

void bubble_sort(int* array, size_t length)
{
    int isSwapped = 1;
    while (isSwapped)
    {
        isSwapped = 0;
        size_t i;
        for (i = 0; i < length - 1; i++)
        {
            if (*(array + i) > *(array + i + 1))
            {
                int oldValue = *(array + i);
                *(array + i) = *(array + i + 1);
                *(array + i + 1) = oldValue;
                isSwapped = 1;
            }
        }
    }
}