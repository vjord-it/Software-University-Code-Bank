#include <stdio.h>
#include <stdlib.h>

int main() 
{
    char *text = "This is a tale about void pointers. Once upon a time...";
    void *voidPtr = text;
//    Cannot derefence a void pointer!
//    printf("%c", *voidPtr); 
    char *ptr = voidPtr;
    printf("%c", *ptr);
    
    return (EXIT_SUCCESS);
}

