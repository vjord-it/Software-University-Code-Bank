#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

void str_to_uppercase(char *str)
{
    while (*str != '\0')
    {
        *str = toupper(*str);
        str++;
    }
}

int main(int argc, char** argv)
{
    char name[] = "softuni";
    str_to_uppercase(name);
    printf("%s", name);
    
    return (EXIT_SUCCESS);
}

