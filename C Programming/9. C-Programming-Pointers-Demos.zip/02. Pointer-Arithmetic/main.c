#include <stdio.h>
#include <stdlib.h>

int main() 
{
    char *text = "Milky Way";
    printf("%c", *text);
    // Move pointer to next element of char sequence
    printf("%c", *(text + 1)); 
    printf("%c", *(text + 2));
    
    printf("\n");
    
    short nums[] = { 1, 5, 7 };
    printf("%d\n", *nums);
    // Move pointer 1 * sizeof(short) bytes to higher memory address
    printf("%d\n", *(nums + 1));
    // Move pointer 2 * sizeof(short) bytes to higher memory address
    printf("%d\n", *(nums + 2));
    
    return (EXIT_SUCCESS);
}

