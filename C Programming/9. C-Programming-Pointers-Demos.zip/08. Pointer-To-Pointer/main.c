#include <stdio.h>
#include <stdlib.h>

void change_pointer_invalid(char *ptr)
{
    // Only changes where the local pointer points
    // Does not affect the pointer in main()
    ptr = "Gosho";
}

void change_pointer_correct(char **ptr)
{
    // Changes where the pointer in main() points to
    *ptr = "Gosho";
}

int main() 
{
    char *str = "Pesho";
    change_pointer_invalid(str);
    printf("%s\n", str);
    
    change_pointer_correct(&str);
    printf("%s\n", str);
    
    return (EXIT_SUCCESS);
}
