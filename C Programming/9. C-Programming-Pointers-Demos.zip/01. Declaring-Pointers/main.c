#include <stdio.h>
#include <stdlib.h>

int main() 
{
    int a = 5;
    int *aPtr = &a;
    a++;
    printf("%d\n", a);
    printf("%d\n", *aPtr); // Dereference pointer
    
    return (EXIT_SUCCESS);
}

