#include <stdio.h>
#include <stdlib.h>

int multiply(int, int);
int add(int, int);
int subtract(int, int);
void calculate(int, int, int (*calc) (int, int));

int main(int argc, char** argv) 
{
    calculate(5, 10, &subtract);
    calculate(5, 10, &add);
    calculate(5, 10, &multiply);
    
    return (EXIT_SUCCESS);
}

void calculate(int a, int b, int (*func) (int, int))
{
    int result = (*func)(a, b);
    printf("%d\n", result);
}

int subtract(int a, int b)
{
    return a - b;
}

int multiply(int a, int b)
{
    return a * b;
}

int add(int a, int b)
{
    return a + b;
}