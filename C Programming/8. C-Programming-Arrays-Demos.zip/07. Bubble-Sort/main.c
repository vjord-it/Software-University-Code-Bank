#include <stdio.h>
#include <stdlib.h>

void bubble_sort(int [], int);
int array_contains(int*, int, int);

void bubble_sort(int array[], int size)
{
    int i, swapped = 1;
    while (swapped)
    {
        // 3, 1, 5, 10, 7, -5
        swapped = 0;
        for (i = 0; i < size - 1; i++)
        {
            if (array[i] > array[i + 1])
            {
                // Swap
                int oldValue = array[i];
                array[i] = array[i + 1];
                array[i + 1] = oldValue;
                swapped = 1;
            }
        }  
    }
}

int array_contains(int *array, int size, int search)
{
    int i;
    for (i = 0; i < size; i++)
    {
        if (array[i] == search)
        {
            return 1;
        }
    }
    
    return 0;
}

int main() 
{
    int array[] = { 5, 3, 1, 10, 7, -5 };
    int size = sizeof(array) / sizeof(int);
    
    bubble_sort(array, size);
    
    int i;
    for (i = 0; i < size; i++)
    {
        printf("%d ", array[i]);
    }

    int containsMinus10 = array_contains(array, size, -10);
    printf("\n");
    printf(containsMinus10 ? "yes" : "no");

    return (EXIT_SUCCESS);
}
