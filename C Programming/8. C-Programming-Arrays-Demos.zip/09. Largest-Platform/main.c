#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

#define ROWS 3
#define COLS 6

int main() 
{
    int matrix[ROWS][COLS] = {
        {7, 1, 3, 3, 2, 1},
        {1, 3, 9, 8, 5, 6},
        {4, 6, 7, 9, 1, 0}
    };
    
    int bestSum = INT_MIN;
    int row, col;
    for (row = 0; row < ROWS - 1; row++)
    {
        for (col = 0; col < COLS - 1; col++)
        {
            int currentSum = matrix[row][col] + matrix[row][col + 1]
                    + matrix[row + 1][col] + matrix[row + 1][col + 1];
            if (currentSum > bestSum)
            {
                bestSum = currentSum;
            }
        }
    }
    
    printf("Best sum: %d", bestSum);
    
    return (EXIT_SUCCESS);
}

