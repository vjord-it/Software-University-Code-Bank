#include <stdio.h>
#include <stdlib.h>

int main() 
{
    int array[] = { 5, 1, 2, 3, 10 };
    int size = sizeof(array) / sizeof(int);
    
    printf("Normal array: \n");
    int i;
    for (i = size - 1; i >= 0; --i)
    {
        printf("%d ", array[i]);
    }
    
    printf("\nSquare elements array: \n");
    int result[size];
    for (i = 0; i < size; i++)
    {
        result[i] = array[i] * array[i];
        printf("%d ", result[i]);
    }
    
    return (EXIT_SUCCESS);
}

