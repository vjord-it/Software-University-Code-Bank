#include <stdio.h>
#include <stdlib.h>

int main() 
{
    float array[] = { 0.5, 0.9, 7.12 };
    printf("array[0] = %.2f\n", array[0]);
    printf("array[1] = %.2f\n", array[1]);
    
    array[0] = 3.14;
    printf("array[0] = %.2f\n", array[0]);
    
    int size = sizeof(array) / sizeof(float);
    int i;
    for (i = 0; i < size; i++)
    {
        printf("%.2f ", array[i]);
    }
    
    return (EXIT_SUCCESS);
}

