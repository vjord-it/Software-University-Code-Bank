#include <stdio.h>
#include <stdlib.h>

#define ROWS 2
#define COLS 2

int main() 
{
    int matrixA[ROWS][COLS] = {
        { 2, 1 },
        { 3, 4 }
    };
    
    int matrixB[ROWS][COLS] = {
        { -1, 3 },
        { 6, 0 }
    };
    
    int resultMatrix[ROWS][COLS];
    int row, col;
    for (row = 0; row < ROWS; row++)
    {
        for (col = 0; col < COLS; col++)
        {
            int i;
            resultMatrix[row][col] = 0;
            for (i = 0; i < ROWS; i++) // change in case different sized matrices
            {
                resultMatrix[row][col] += matrixA[row][i]
                        * matrixB[i][col];
            }
        }
    }
    
    for (row = 0; row < ROWS; row++)
    {
        for (col = 0; col < COLS; col++)
        {
            printf("%-5d", resultMatrix[row][col]);
        }
        
        printf("\n");
    }
    
    return (EXIT_SUCCESS);
}

