#include <stdio.h>
#include <stdlib.h>

int main() 
{
    int n;
    int matches = scanf("%d", &n);
    if (matches != 1)
    {
        printf("Invalid input format");
        return 1;
    }
    
    int lastDigit = n % 10;
    char *digitsAsWord[] = { "zero", "one", "two", "three", "four",
            "five", "six", "seven", "eight", "nine" };
    
    printf("%s", digitsAsWord[lastDigit]);
    
    return (EXIT_SUCCESS);
}

