#include <stdio.h>
#include <stdlib.h>

#define ROWS 2
#define COLS 2

int main() 
{ 
    int matrix[ROWS][COLS];
    int row, col;
    for (row = 0; row < ROWS; row++)
    {
        for (col = 0; col < COLS; col++)
        {
            scanf("%d", &matrix[row][col]);
        }
    }
    
    return (EXIT_SUCCESS);
}

