#include <stdio.h>
#include <stdlib.h>

int main() 
{
    int n;
    scanf("%d", &n);
    
    char digitCharacters[] = { '0', '1', '2', '3', '4', 
                    '5', '6', '7', '8', 
                    '9', 'A', 'B', 'C', 'D', 'E', 'F' };
    
    char result[8];
    int index = 0;
    while (n > 0)
    {
        int digit = n % 16;
        result[index] = digitCharacters[digit];
        index++;
        n /= 16;
    }
    
    int i;
    for (i = index - 1; i >= 0; i--)
    {
        printf("%c", result[i]);
    }
    
    
    return (EXIT_SUCCESS);
}

