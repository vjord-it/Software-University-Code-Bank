#include <stdio.h>
#include <stdlib.h>

#define STRING_COUNT 3

int main(int argc, char** argv)
{
    char name[] = "Georgi";
    name[0] = 'P';
    name[-1] = 'A'; // Invalid memory access!
    name[5] = 'K';  // Invalid memory access!
    printf("%s", name);
    
    char text[128];
    memset(text, 0, 128);
    fgets(text, 128, stdin);
    
    const char *line = "Hello, C";
    line[0] = 'A'; // Segmentation fault!
    
    return (EXIT_SUCCESS);
}

