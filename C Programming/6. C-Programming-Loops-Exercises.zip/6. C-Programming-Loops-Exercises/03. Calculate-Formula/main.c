#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main() 
{
    int n, x;
    scanf("%d %d", &n, &x);
    
    double sum = 1;
    int i;
    double nominator = 1, denominator = 1;
    for (i = 1; i <= n; i++)
    {
        // 1 2 6 
        nominator *= i;
        // 3 9 27
        denominator *= x;
        sum += nominator / denominator;
    }
    
    printf("%.5f", sum);
    
    return (EXIT_SUCCESS);
}

