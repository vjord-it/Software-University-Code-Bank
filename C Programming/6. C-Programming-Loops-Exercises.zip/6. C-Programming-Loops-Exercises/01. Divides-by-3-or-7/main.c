#include <stdio.h>
#include <stdlib.h>

int main() 
{
    int n;
    scanf("%d", &n);
    
    int num;
    for (int num = 1; num <= n; num++)
    {
        int dividesBy3 = num % 3 == 0;
        int dividesBy7 = num % 7 == 0;
        int dividesBy3or7 = dividesBy3 || dividesBy7;
        if (!dividesBy3or7)
        {
            printf("%d\n", num);
        } 
    }

//    while (num <= n)
//    {
//        int dividesBy3 = num % 3 == 0;
//        int dividesBy7 = num % 7 == 0;
//        int dividesBy3or7 = dividesBy3 || dividesBy7;
//        if (!dividesBy3or7)
//        {
//            printf("%d\n", num);
//        }
//        
//        num++;
//    }
    
    return (EXIT_SUCCESS);
}

