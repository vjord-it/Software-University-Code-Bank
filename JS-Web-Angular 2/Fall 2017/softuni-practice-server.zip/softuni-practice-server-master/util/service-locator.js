const services = {};

module.exports = {
    initialize: config => {},
    services
}