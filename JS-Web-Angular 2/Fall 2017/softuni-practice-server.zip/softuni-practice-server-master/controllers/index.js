const auth = require('../util/auth');
const collection = require('./collection');
/*
const cars = require('./cars');
const people = require('./people');
*/

module.exports = {
    auth,
    collection
};