// TODO add error handling for incorrect requests

module.exports = require('./defaultController')('cars');