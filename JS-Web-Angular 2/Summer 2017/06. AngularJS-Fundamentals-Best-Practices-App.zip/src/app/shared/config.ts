export let CONFIG = {
  baseUrls: {
    config: 'commands/config',
    courses: 'api/courses.json',
  }
}
