export interface Course {
  id: number;
  name: string;
  topic: string;
}