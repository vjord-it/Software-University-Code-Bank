const home = require('./home-controller')
const users = require('./users-controller')

module.exports = {
  home: home,
  users: users
}
