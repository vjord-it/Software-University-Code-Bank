﻿using Microsoft.AspNetCore.Identity;

namespace VideoOnDemand.Data.Data.Entities
{
    public class User : IdentityUser
    {
    }
}
