﻿namespace VideoOnDemand.UI.Models.DTOModels
{
    public class DownloadDTO
    {
        public string DownloadUrl { get; set; }
        public string DownloadTitle { get; set; }
    }
}
