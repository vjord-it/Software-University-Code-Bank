﻿namespace AspNetVideoCore.Services
{
    public interface IMessageService
    {
        string GetMessage();
    }
}
