package hell.interfaces;

public interface Runnable {

    void run();
}
