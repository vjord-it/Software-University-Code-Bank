package hell.interfaces;

public interface Executable {

    String execute() throws IllegalAccessException;
}
