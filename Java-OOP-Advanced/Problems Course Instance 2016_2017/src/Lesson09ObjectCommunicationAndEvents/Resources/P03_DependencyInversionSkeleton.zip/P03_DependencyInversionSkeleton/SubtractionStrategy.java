package P03_DependencyInversion;

public class SubtractionStrategy {
    public int Calculate(int firstOperand, int secondOperand){
        return firstOperand - secondOperand;
    }
}
