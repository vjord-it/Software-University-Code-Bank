package pr0304Barracks.contracts;

public interface Destroyable {
    
    int getHealth();
    
    void setHealth(int health);
}
