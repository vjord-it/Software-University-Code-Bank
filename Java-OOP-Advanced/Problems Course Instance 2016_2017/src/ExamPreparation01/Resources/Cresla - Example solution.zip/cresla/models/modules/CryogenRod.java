package cresla.models.modules;

public class CryogenRod extends AbstractEnergyModule{

    public CryogenRod(int id, int output) {
        super(id, output);
    }
}
